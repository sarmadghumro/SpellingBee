# Spelling Bee Answers Website

Simple static website for GitHub and Vercel deployment.

## Files Included

- index.html
- style.css
- script.js

## Deployment

1. Upload to GitHub
2. Import repository into Vercel
3. Click Deploy
