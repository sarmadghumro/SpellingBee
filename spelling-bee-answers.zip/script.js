const searchInput = document.getElementById('searchInput');
const answersGrid = document.getElementById('answersGrid');

searchInput.addEventListener('keyup', () => {

    const filter = searchInput.value.toLowerCase();

    const words = answersGrid.getElementsByTagName('span');

    for (let i = 0; i < words.length; i++) {

        let text = words[i].textContent || words[i].innerText;

        if (text.toLowerCase().indexOf(filter) > -1) {
            words[i].style.display = '';
        } else {
            words[i].style.display = 'none';
        }
    }
});
